exports.TOKEN = 'ODgyOTU4Mjg0NDM1MzkwNDk0.YTC8-w.2qFEvLn6hpS9LrvxUZ_VNjuO3dA'; //https://discord.com/developers/applications

exports.DBL_API_KEY = ''; //https://top.gg

exports.PREFIX = ',';

exports.GOOGLE_API_KEY = ''; // https://console.cloud.google.com/apis/library/youtube.googleapis.com

exports.GENIUS_API_KEY = '1u8TNVtNqh7fBDjxXtRAxZZ7HP2YKthVk_daI-hOBmwz9xHf8ifu4YYHuo3yu94X'; // https://genius.com/developers

exports.yandex_API = 'pdct.1.1.20210907T073230Z.33f4eb8d8e285b4d.67da88ca542f53348aed2c0af8fe6bcb7eec4177'; // https://yandex.com/dev/predictor/keys/get/

exports.news_API = '63d9456571334faaa2ea6f842d32f595'; // https://newsapi.org/

exports.giphy_API = ''; // https://developers.giphy.com/

exports.AME_API = 'b13d9f935cb1ed3793d28ddc3b14864b1a1a3df216b93d5394610c3bee669fc38b38ee61e6b9a6003e839155f75d0b5f6e5771b11ad8c14b061c08dd42525174'; // https://api.amethyste.moe

exports.blague_API = ''; // https://blague.xyz/

exports.mongo_db = 'mongodb+srv://Navdeeep:abcd1234----@economybot.ikqik.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';