name         | about
------------ | ----------------------------------------------
Bug report | Report incorrect or unexpected behaviour

**Please describe the problem you are having in as much detail as possible:**

**Further details:**

* Version:

* Priority this issue should have – please be realistic and elaborate if possible:

- [ ] I found this issue while self-hosting the bot.

  - Node.js version:
  - Commit hash:
  - Operating system:
