Hello, I'm the owner of this bot 1SHOT.
This is a feature-rich bot with multiple purposes - Music, High Moderation, Fun, Info, Economy System, discord-telephone, Image Manipulation.
It has over 120 commands! Made with discord.js and last but not the least, Multi and Singleplayer Games for your entertainment! This repo provides support to everyone, feel free to open an issue

STAR THE PROJECT IF YOU LIKE IT :)

## List of Commands - ##
* Economy
  - addmoney
  - balance
  - beg
  - buy
  - daily
  - deposit
  - fish
  - leaderboard
  - pay
  - profile
  - removemoney
  - rob
  - roulette
  - sell
  - setbackground
  - setinfo
  - slots
  - store
  - weekly
  - withdraw
  - work

* Fun
  - coinflip
  - meme
  - motivation
  - roast
  - say
  - soundboard
  - status
  - tts
  - urbandictionary

* Games
  - akinator
  - blackjack
  - connectfour
  - duelquiz
  - gunfight
  - horserace
  - memory
  - rps
  - russianroulette
  - tictactoe
  - trivia

* Image
  - avatar
  - avatarfusion
  - captcha
  - clyde
  - facepalm
  - fire
  - gif
  - jail
  - love
  - mission
  - phcomment
  - rip
  - scary
  - tobecontinued
  - triggered
  - tweet
  - wasted

* Info
  - channelinfo
  - help
  - instasearch
  - invitations
  - level
  - news
  - ping
  - poll
  - roleinfo
  - rolememberinfo
  - serverinfo
  - translate
  - uptime
  - weather
  - whois
  - wikipedia

* Moderation
  - addrole
  - ban
  - disablemodlogchannel
  - disablemuterole
  - disableverification
  - disablewelcomechannel
  - disablexp
  - kick
  - mute
  - purge
  - removerole
  - setmodlogchannel
  - setmuterole
  - setnick
  - setprefix
  - setverification
  - setwelcomechannel
  - setxp
  - unban
  - unmute
  - verify
  - warn

* Music
  - join
  - leave
  - loop
  - lyrics
  - musictrivia
  - nowplaying
  - pause
  - play
  - queue
  - remove
  - resume
  - search
  - shuffle
  - skip
  - skipall
  - skipto
  - stop
  - stopmusictrivia
  - volume

* Owner
  - eval
  - getinvite
  - serverlist

* Phone
  - hangup
  - phonebook
  - phonecall
  - setphonechannel
